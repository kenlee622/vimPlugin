
for (infinity = 0; infinity < abc; infinity++) {
	/* code */
}
